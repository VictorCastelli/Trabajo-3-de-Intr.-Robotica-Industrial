#! /usr/bin/env python3

import rospy 
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
import numpy as np
import math
from tf.transformations import euler_from_quaternion, quaternion_from_euler

class Environment():
    def __init__(self, target_x, target_y):
        rospy.Subscriber('/odom', Odometry, self.odometry_callback)
        rospy.Subscriber('/base_scan', LaserScan, self.laser_callback)
        self.pub_cmd_vel = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
        self.odometry = Odometry()
        self.laser = LaserScan()
        self.position_robot_x = 0.
        self.position_robot_y = 0.
        self.goal_y = target_y
        self.goal_x = target_x
        rospy.sleep(0.5)
        
        
    def odometry_callback(self, data):
        self.odometry = data
        self.position_robot_x = data.pose.pose.position.x
        self.position_robot_y = data.pose.pose.position.y
        orientation = data.pose.pose.orientation
        orientation_list = [orientation.x, orientation.y, orientation.z, orientation.w]
        _, _, self.yaw = euler_from_quaternion(orientation_list)
        self.goal_angle = math.atan2(self.goal_y - self.position_robot_y, self.goal_x - self.position_robot_x)
    
    def laser_callback(self, data):
        self.laser = data
    
    def step(self, action):
        linear_vel = action[0]
        ang_vel = action[1]
        
        vel_cmd = Twist()
        vel_cmd.linear.x = linear_vel
        vel_cmd.angular.z = ang_vel
        
        self.pub_cmd_vel.publish(vel_cmd)
        
    def shutdown(self):
        rospy.loginfo("Lugar alcancado!!! o/ \o")
        self.pub_cmd_vel.publish(Twist())
        

if __name__ == "__main__":
    rospy.init_node('stage_controller_node', anonymous=False)
    
    ok = 0
    
    target_x = -3.0
    target_y = 5.0
    
    subtarget1_x = 1.8
    subtarget1_y = 0.0
    
    subtarget2_x = -2.0
    subtarget2_y = -1.0
    
    subtarget3_x = -1.5
    subtarget3_y = 1.0
    
    subtarget4_x = 2.0
    subtarget4_y = 3.5
    
    subtarget5_x = 3.0
    subtarget5_y = 5.0 
     
    subtarget6_x = 0.0
    subtarget6_y = 6.0  
    
    subtarget7_x = -1.5
    subtarget7_y = 4.0  
	
    env = Environment(target_x, target_y)
       
    
    min_distance = 0.3
    step = 0.5
    action = np.zeros(2)
    
    r = rospy.Rate(10)
    
    while not rospy.is_shutdown():
        
        x_robot = env.position_robot_x
        y_robot = env.position_robot_y
        yaw_robot = env.yaw
        
        distance_robot = math.sqrt((x_robot - target_x)**2 + (y_robot - target_y)**2)
        distance_subtarget1 = math.sqrt((x_robot - subtarget1_x)**2 + (y_robot - subtarget1_y)**2)
        distance_subtarget2 = math.sqrt((x_robot - subtarget2_x)**2 + (y_robot - subtarget2_y)**2)
        distance_subtarget3 = math.sqrt((x_robot - subtarget3_x)**2 + (y_robot - subtarget3_y)**2)
        distance_subtarget4 = math.sqrt((x_robot - subtarget4_x)**2 + (y_robot - subtarget4_y)**2)
        distance_subtarget5 = math.sqrt((x_robot - subtarget5_x)**2 + (y_robot - subtarget5_y)**2)
        distance_subtarget6 = math.sqrt((x_robot - subtarget6_x)**2 + (y_robot - subtarget6_y)**2)
        distance_subtarget7 = math.sqrt((x_robot - subtarget7_x)**2 + (y_robot - subtarget7_y)**2)
          
	
        goal_angle = math.atan2(target_y - y_robot, target_x - x_robot)
        subtarget1_angle = math.atan2(subtarget1_y - y_robot, subtarget1_x - x_robot)
        subtarget2_angle = math.atan2(subtarget2_y - y_robot, subtarget2_x - x_robot)
        subtarget3_angle = math.atan2(subtarget3_y - y_robot, subtarget3_x - x_robot)
        subtarget4_angle = math.atan2(subtarget4_y - y_robot, subtarget4_x - x_robot)
        subtarget5_angle = math.atan2(subtarget5_y - y_robot, subtarget5_x - x_robot)
        subtarget6_angle = math.atan2(subtarget6_y - y_robot, subtarget6_x - x_robot)
        subtarget7_angle = math.atan2(subtarget7_y - y_robot, subtarget7_x - x_robot)  
        
        # Exemplo abaixo ----------------------------------------------------------------
        if distance_robot > min_distance:
            #rospy.loginfo('Aonde estou: X--> %s, Y--> %s', x_robot, y_robot)
            
            if (min(env.laser.ranges) < 0.2):
                action[0] = 0.
                action[1] = -0.5
            else:
                action[0] = 0.3
                action[1] = 0.0
            
            env.step(action)
        else:
            env.shutdown()
         #Termino do exemplo--------------------------------------------------------------------------------
         
        while distance_subtarget1 > min_distance and not ok:
        
          x_robot = env.position_robot_x
          y_robot = env.position_robot_y
          yaw_robot = env.yaw

          distance_subtarget1 = math.sqrt((x_robot - subtarget1_x)**2 + (y_robot - subtarget1_y)**2)
          subtarget1_angle = math.atan2(subtarget1_y - y_robot, subtarget1_x - x_robot)
          
          correcion = subtarget1_angle - yaw_robot 	
          if correcion < 0.005:
            action[0] = 0.0
            action[1] = correcion
          elif correcion > 0.005:
            action[0] = 0.0
            action[1] = -correcion
          env.step(action)
          rospy.sleep(0.0005)
          #rospy.loginfo('SubTarget 1 - Aonde estou: X--> %s, Y--> %s', x_robot, y_robot)
          rospy.loginfo('Correcion1--> %s', correcion)
          #rospy.loginfo('Correccion--> %s Ang Z--> %s', correcion, yaw_robot)
		    
          if (min(env.laser.ranges) < 0.2):
            
            if (env.laser.angle_min < 134):
              action[0] = 0.001
              action[1] = 2
            else:
              action[0] = 0.001
              action[1] = -2
          else:
            action[0] = step
            action[1] = 0.0
              
          env.step(action)
          rospy.sleep(0.0005)
     ##############################################################################     
        while distance_subtarget2 > min_distance and not ok:
        
          x_robot = env.position_robot_x
          y_robot = env.position_robot_y
          yaw_robot = env.yaw

          distance_subtarget2 = math.sqrt((x_robot - subtarget2_x)**2 + (y_robot - subtarget2_y)**2)
          subtarget2_angle = math.atan2(subtarget2_y - y_robot, subtarget2_x - x_robot)
          
		    
          if (min(env.laser.ranges) < 0.2):
            
            if (env.laser.angle_min < 134):
              action[0] = 0.0
              action[1] = 1.1
              env.step(action)
            else:
              action[0] = 0.0
              action[1] = -1.1
              env.step(action)
          else:
            action[0] = step
            action[1] = 0.0
            env.step(action)  
            rospy.sleep(0.0005)
            correcion = subtarget2_angle - yaw_robot 	
            if correcion < 0.005:
              action[0] = 0.0
              action[1] = correcion
            elif correcion > 0.005:
              action[0] = 0.0
              action[1] = -correcion
            
            env.step(action)
            rospy.loginfo('Correcion2--> %s', correcion)            
              
          
          rospy.sleep(0.0005)
     ##############################################################################     
     
        while distance_subtarget3 > min_distance and not ok:
        
          x_robot = env.position_robot_x
          y_robot = env.position_robot_y
          yaw_robot = env.yaw

          distance_subtarget3 = math.sqrt((x_robot - subtarget3_x)**2 + (y_robot - subtarget3_y)**2)
          subtarget3_angle = math.atan2(subtarget3_y - y_robot, subtarget3_x - x_robot)
          
          if (min(env.laser.ranges) < 0.2):
            
            if (env.laser.angle_min < 134):
              action[0] = 0.0
              action[1] = 1.1
              env.step(action)
            else:
              action[0] = 0.0
              action[1] = -1.1
              env.step(action)
          else:
            action[0] = step
            action[1] = 0.0
            env.step(action)  
            rospy.sleep(0.0005)
            correcion = subtarget3_angle - yaw_robot 	
            if correcion < 0.005:
              action[0] = 0.0
              action[1] = correcion
            elif correcion > 0.005:
              action[0] = 0.0
              action[1] = -correcion
            
            env.step(action)
            rospy.loginfo('Correcion3--> %s', correcion)            
              
          
          rospy.sleep(0.0005)
     ##############################################################################     
     
        while distance_subtarget4 > min_distance and not ok:
        
          x_robot = env.position_robot_x
          y_robot = env.position_robot_y
          yaw_robot = env.yaw

          distance_subtarget4 = math.sqrt((x_robot - subtarget4_x)**2 + (y_robot - subtarget4_y)**2)
          subtarget4_angle = math.atan2(subtarget4_y - y_robot, subtarget4_x - x_robot)
          
          if (min(env.laser.ranges) < 0.2):
            
            if (env.laser.angle_min < 134):
              action[0] = 0.0
              action[1] = 1.1
              env.step(action)
            else:
              action[0] = 0.0
              action[1] = -1.1
              env.step(action)
          else:
            action[0] = step
            action[1] = 0.0
            env.step(action)  
            rospy.sleep(0.0005)
            correcion = subtarget4_angle - yaw_robot 	
            if correcion < 0.005:
              action[0] = 0.0
              action[1] = correcion
            elif correcion > 0.005:
              action[0] = 0.0
              action[1] = -correcion
            
            env.step(action)
            rospy.loginfo('Correcion4--> %s', correcion)            
              
          
          rospy.sleep(0.0005)
     ##############################################################################     
     
        while distance_subtarget5 > min_distance and not ok:
        
          x_robot = env.position_robot_x
          y_robot = env.position_robot_y
          yaw_robot = env.yaw

          distance_subtarget5 = math.sqrt((x_robot - subtarget5_x)**2 + (y_robot - subtarget5_y)**2)
          subtarget5_angle = math.atan2(subtarget5_y - y_robot, subtarget5_x - x_robot)
          
          if (min(env.laser.ranges) < 0.2):
            
            if (env.laser.angle_min < 134):
              action[0] = 0.0
              action[1] = 1.1
              env.step(action)
            else:
              action[0] = 0.0
              action[1] = -1.1
              env.step(action)
          else:
            action[0] = step
            action[1] = 0.0
            env.step(action)  
            rospy.sleep(0.0005)
            correcion = subtarget5_angle - yaw_robot 	
            if correcion < 0.005:
              action[0] = 0.0
              action[1] = -correcion
            elif correcion > 0.005:
              action[0] = 0.0
              action[1] = correcion
            
            env.step(action)
            rospy.loginfo('Correcion5--> %s', correcion)            
              
          
          rospy.sleep(0.0005)
     ##############################################################################     
     
        while distance_subtarget6 > min_distance and not ok:
        
          x_robot = env.position_robot_x
          y_robot = env.position_robot_y
          yaw_robot = env.yaw

          distance_subtarget6 = math.sqrt((x_robot - subtarget6_x)**2 + (y_robot - subtarget6_y)**2)
          subtarget6_angle = math.atan2(subtarget6_y - y_robot, subtarget6_x - x_robot)
          
          if (min(env.laser.ranges) < 0.2):
            
            if (env.laser.angle_min < 134):
              action[0] = 0.0
              action[1] = 1.1
              env.step(action)
            else:
              action[0] = 0.0
              action[1] = -1.1
              env.step(action)
          else:
            action[0] = step
            action[1] = 0.0
            env.step(action)  
            rospy.sleep(0.0005)
            correcion = subtarget6_angle - yaw_robot 	
            if correcion < 0.005:
              action[0] = 0.0
              action[1] = -correcion
            elif correcion > 0.005:
              action[0] = 0.0
              action[1] = correcion
            
            env.step(action)
            rospy.loginfo('Correcion6--> %s', correcion)            
              
          
          rospy.sleep(0.0005)
     ##############################################################################     
     
        while distance_subtarget7 > min_distance and not ok:
        
          x_robot = env.position_robot_x
          y_robot = env.position_robot_y
          yaw_robot = env.yaw

          distance_subtarget7 = math.sqrt((x_robot - subtarget7_x)**2 + (y_robot - subtarget7_y)**2)
          subtarget7_angle = math.atan2(subtarget7_y - y_robot, subtarget7_x - x_robot)
          if (min(env.laser.ranges) < 0.2):
            
            if (env.laser.angle_min < 134):
              action[0] = 0.0
              action[1] = 1.1
              env.step(action)
            else:
              action[0] = 0.0
              action[1] = -1.1
              env.step(action)
          else:
            action[0] = step
            action[1] = 0.0
            env.step(action)  
            rospy.sleep(0.0005)
            correcion = subtarget7_angle - yaw_robot 	
            if correcion < 0.005:
              action[0] = 0.0
              action[1] = -correcion
            elif correcion > 0.005:
              action[0] = 0.0
              action[1] = correcion
            
            env.step(action)
            rospy.loginfo('Correcion7--> %s', correcion)            
              
          
          rospy.sleep(0.0005)
     ##############################################################################     
     
        while distance_robot > (min_distance + 0.00000000000001)-0.2:
          ok = 1	
          x_robot = env.position_robot_x
          y_robot = env.position_robot_y
          yaw_robot = env.yaw

          distance_robot = math.sqrt((x_robot - target_x)**2 + (y_robot - target_y)**2)
          goal_angle = math.atan2(target_y - y_robot, target_x - x_robot)
          
          correcion = goal_angle - yaw_robot 	
          if correcion < 0.005:
            action[0] = 0.0
            action[1] = correcion
          elif correcion > 0.005:
            action[0] = 0.0
            action[1] = -correcion
          
          env.step(action)
          rospy.sleep(0.0005)
          #rospy.loginfo('SubTarget 3 - Aonde estou: X--> %s, Y--> %s', x_robot, y_robot)
          rospy.loginfo('CorrecionT--> %s', correcion)
          #rospy.loginfo('Correccion--> %s Ang Z--> %s', correcion, yaw_robot)
		    
          if (min(env.laser.ranges) < 0.2):
            
            if (env.laser.angle_min < 134):
              action[0] = 0.001
              action[1] = 1.1
            else:
              action[0] = 0.001
              action[1] = -1.1
          else:
            action[0] = step
            action[1] = 0.0
              
          env.step(action)
          rospy.sleep(0.0005)
          
          distance_robot = math.sqrt((x_robot - target_x)**2 + (y_robot - target_y)**2)
          if distance_robot < min_distance  - 0.2:
            env.shutdown()
                  
        r.sleep()
              
        
